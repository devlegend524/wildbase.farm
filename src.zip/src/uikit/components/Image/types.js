export const variants = {
  DEFAULT: 'default',
  INVERTED: 'inverted',
} 