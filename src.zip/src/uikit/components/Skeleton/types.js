export const animation = {
  WAVES: 'waves',
  PULSE: 'pulse',
}

export const variant = {
  RECT: 'rect',
  CIRCLE: 'circle',
}
