import React from 'react'
import Overlay from './Overlay'

export default {
  title: 'Components/Overlay',
  argTypes: {},
}

export const Default = () => {
  return <Overlay show />
}
