import React from 'react'

const Icon = (props) => {
  return <img {...props} src='/images/tokens/wild.svg' alt='' />
}

export default Icon
