export { default as Text } from './Text'
export { default as TooltipText } from './TooltipText'
