export const scales = {
  SM: 'sm',
  MD: 'md',
} 