const getExternalLinkProps = () => ({
  target: '_blank',
  rel: 'noreferrer noopener',
})

export default getExternalLinkProps
